import { MidwayConfig } from '@midwayjs/core';
import { Adminer } from '../entity/adminer';
import { User } from '../entity/user';
import { Note } from '../entity/note';
import { Trade } from '../entity/trade';

export default {
  // use for cookie sign key, should change to your own and keep security
  keys: '1680167318186_2690',
  koa: {
    port: 7003,
    web: 'http://zfxy.zcfsjt.com',
    server: 'http://zfxyadmin.zcfsjt.com'
  },
  wechat: {
    appid: 'wx8cb2ab99bc41710a',
    secret: 'acf1f3369fd0f301ae08868616396b9e',
    templateId: 'YwBjAX1MDijm17BiwfcY04-6d5MGPVbmBhfZe5K3QvU'
  },
  redis: {
    client: {
      port: 6379, // Redis port
      host: "127.0.0.1", // Redis host
      password: "",
      // db: 0,
      end: 60 * 60 * 24 * 30 // 30天过期
    },
  },
  jwt: {
    secret: '415254f3-6052-4e83-9bd1-2318850ad61b',
    expiresIn: '2h',
  },
  sequelize: {
    dataSource: {
      // 第一个数据源，数据源的名字可以完全自定义
      default: {
        database: 'zfxy',
        username: 'zfxy',
        password: 'jFAkxTbMZ6sY5t64',
        host: '127.0.0.1',
        port: 3306,
        encrypt: false,
        dialect: 'mysql',
        define: { charset: 'utf8' },
        timezone: '+08:00',
        entities: [Adminer, User, Note, Trade],
        // 本地的时候，可以通过 sync: true 直接 createTable
        sync: true,
      },
    },
  },
} as MidwayConfig;
